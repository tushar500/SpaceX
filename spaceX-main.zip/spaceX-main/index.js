require("@babel/register")

require('./Server')