# spaceX
A front-end application which would help users list and browse all launches by SpaceX program
- Clone the repo:

```bash
git clone https://github.com/DikshantAgarwal/spaceX.git
```
- Go to the project directory and install dependencies:

```bash
cd spaceX && npm install
```  
- Launch the server

```bash
npm start
```

Now, the application is running at http://localhost:8080. The initial homepage is Sever Rendered.
